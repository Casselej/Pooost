extends Control

@onready var Frame = $"."
var extemnded := false

func _ready() -> void:
	extemnded = false
	Frame.offset_left = 1000
func _MotherSunOfShit():
	if extemnded == true:
		get_tree().create_tween().tween_property(Frame, "offset_left", 1000, 1).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN)
		extemnded = false
	else:
		get_tree().create_tween().tween_property(Frame, "offset_left", 0, 0.6).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
		extemnded = true
