extends Control

@onready var ButtonsAndTitle = $ButtonsAndTitle
@onready var SingleplayerFrame = $SingleplayerFrame

func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	print("Loaded")

func _input(event: InputEvent) -> void:
	if Input.is_action_just_pressed("Escape"):
		if not SingleplayerFrame.offset_left > 1:
			if SingleplayerFrame.extemnded:
				SingleplayerFrame._MotherSunOfShit()
			else:
				pass
		else:
			get_tree().quit()
func _on_singleplayer_button_pressed() -> void:
	SingleplayerFrame._MotherSunOfShit()


func _on_quit_button_pressed() -> void:
	get_tree().quit()


func _on_texture_button_pressed() -> void:
	get_tree().change_scene_to_file("res://Scenes/main_map.tscn")
