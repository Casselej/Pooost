extends Camera3D

@onready var camera = $"."

#Headbob vars
var Bob_Freq = 0.3
var Bob_Amp = 1
var t_bob = 0.0

func _physics_process(delta: float) -> void:
	t_bob += delta
	camera.transform.origin = _headbob(t_bob)

func _headbob(time) -> Vector3:
	var Pos = Vector3.ZERO
	Pos.y = sin(time * Bob_Freq) * Bob_Amp
	Pos.x = cos(time * Bob_Freq / 3.225) * Bob_Amp * 1
	return Pos
