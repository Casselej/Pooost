extends CharacterBody3D

#Speed vars
var Speed = 3.0
var Sens = 0.003
const RUNSPEED = 5.0
const WALKSPEED = 3.0
const CROUCHSPEED = 1.25
var Speed_Multiplier = 1.0
var Acceleration : float = 2.0

#Jump var
const JUMP_VELOCITY = 4
var Air_Cuntroll = 1.2

#Headbob vars
var Bob_Freq = 2.0
var Bob_Amp = 0.08
var t_bob = 0.0

#CamTit
var CamTiltLeft = 5.0
var CamTiltRight = -5.0

#states
var Sprinting = false
var Crouching = false
var Walking = false
var Idle = true
var Dead = false

var Health := 100

var Zooming := false

var MouseUnlocked : bool = false

var Fov_Change_Speed = 4
var Base_Fov = 90.0
var Fov_Change = 3
var ZoomAmoumnd = 2.0

const STAND_HEIGHT = 1.713
const CROUCH_HEIGHT = 0.7

@onready var learn = $Lean
@onready var head = $Lean/Neck/Head
@onready var camera = $Lean/Neck/Head/Camera3D
@onready var neck = $Lean/Neck
@onready var CrouchCollider = $CrouchCollider
@onready var StandCollider = $StandCollider
@onready var CrouchShapeCast = $ShapeCast3D
@onready var CrouchBackupRay = $CrouchBAckup

@onready var AltCamera = $Lean/Neck/Head/Camera3D/AlternativeCamera
var TopVeloctiy = 0.0

#Piss vars
@onready var PissParticle = $Lean/Neck/Head/PissEmitter
var PissStregnth := 1.0
var PissAmount := 10.0

func _input(event: InputEvent) -> void:
	if Input.is_action_pressed("Crouch") and Dead == false:
		Crouching = true
		Sprinting = false
	elif not CrouchShapeCast.is_colliding() and not CrouchBackupRay.is_colliding():
		Crouching = false
	
	if Input.is_action_just_pressed("DebugK"):
		_debugrotateadd90degrees()
	
	if Input.is_action_just_pressed("UnlockMouse"):
		if MouseUnlocked == true:
			MouseUnlocked = false
		else:
			MouseUnlocked = true
		
	if Input.is_action_pressed("Escape"):
		get_tree().change_scene_to_file("res://Scenes/main_menu.tscn")
		
	if Input.is_action_pressed("DebugAltCamera"):
		AltCamera.current = true
		camera.current = false
	else:
		AltCamera.current = false
		camera.current = true
	
	if Input.is_action_just_pressed("DebugL"):
		_debugresetcamheadrot()
	
	if event is InputEventMouseMotion and Dead == false:
		if Input.get_mouse_mode() == Input.MOUSE_MODE_CAPTURED:
			neck.rotate_y(-event.relative.x * Sens)
			head.rotate_x(-event.relative.y * Sens)
			head.rotation.x = clamp(head.rotation.x, deg_to_rad(-75), deg_to_rad(90))
			
	if Input.is_action_pressed("Zoom") and Dead == false:
		Zooming = true
	else:
		Zooming = false
	
	# Handle jump.
	if Input.is_action_pressed("LeJump") and is_on_floor() and not Crouching and Dead == false:
		velocity.y = JUMP_VELOCITY
	
	if Input.is_action_pressed("RunAwayEEEK") and not Crouching and Dead == false:
		Sprinting = true
		Crouching = false
		Idle = false
		Speed = RUNSPEED
	else:
		Sprinting = false
		Speed = WALKSPEED
	
func _physics_process(delta: float) -> void:
	_CheckForDeath()
	
	if PissAmount < 100:
		PissAmount += 0.01
	
	if Input.is_action_pressed("Piss"):
		PissParticle.emitting = true
		if PissAmount < 0.1:
			PissParticle.emitting = false
		if PissAmount > 0.1:
			PissAmount -= 1 * delta
	else:
		PissParticle.emitting = false
	
	var OldVelocity := velocity
	
	if MouseUnlocked == false:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	else:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta
	
	#handle Crouching
	if Crouching and Dead == false:
		#Bob_Amp = lerp(Bob_Amp, 0.12, delta * 2)
		get_tree().create_tween().tween_property(self, "Bob_Amp", 0.12, 0.4)
		Speed = CROUCHSPEED
		CrouchCollider.disabled = false
		StandCollider.disabled = true
		neck.position.y = lerp(neck.position.y, CROUCH_HEIGHT, delta * 10)
	elif !CrouchShapeCast.is_colliding() and not CrouchBackupRay.is_colliding():
			#Bob_Amp = lerp(Bob_Amp, 0.08, delta * 2)
			get_tree().create_tween().tween_property(self, "Bob_Amp", 0.08, 1.4)
			neck.position.y = lerp(neck.position.y, STAND_HEIGHT, delta * 2)
			CrouchCollider.disabled = true
			StandCollider.disabled = false
			
	if Input.is_action_pressed("Left") and Dead == false:
		if Sprinting:
			camera.rotation.z = lerp(camera.rotation.z, deg_to_rad(CamTiltLeft * 2), delta * 2)
		else:
			camera.rotation.z = lerp(camera.rotation.z, deg_to_rad(CamTiltLeft), delta * 2)
		
	if Input.is_action_pressed("LeftSquared") and Dead == false:
		if Sprinting:
			camera.rotation.z = lerp(camera.rotation.z, deg_to_rad(CamTiltRight * 2), delta * 2)
		else:
			camera.rotation.z = lerp(camera.rotation.z, deg_to_rad(CamTiltRight), delta * 2)
	if not Input.is_action_pressed("Left") and not Input.is_action_pressed("LeftSquared"):
		camera.rotation.z = lerp(camera.rotation.z, 0.0, delta * 2)
		
	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var input_dir := Input.get_vector("Left", "LeftSquared", "Forward", "NotForward")
	var direction = (neck.transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	if is_on_floor() and Dead == false:
		if direction:
			velocity.x = lerp(velocity.x, direction.x * Speed, delta * Acceleration)
			velocity.z = lerp(velocity.z, direction.z * Speed, delta * Acceleration)
			Walking = true
			Idle = false
		else:
			velocity.x = lerp(velocity.x, 0.0, delta * 3)
			velocity.z = lerp(velocity.z, 0.0, delta * 3)
			Walking = false
			Idle = true
	else:
		if direction:
			velocity.x = lerp(velocity.x, direction.x * Speed * 0.9, delta * Air_Cuntroll)
			velocity.z = lerp(velocity.z, direction.z * Speed * 0.9, delta * Air_Cuntroll)
			Walking = true
			Idle = false
		else:
			velocity.x = lerp(velocity.x, 0.0, delta * 0.2)
			velocity.z = lerp(velocity.z, 0.0, delta * 0.2)
			Walking = false
			Idle = true
	
	if is_on_floor():
		t_bob += delta * velocity.length()
	else:
		t_bob += delta * velocity.length() / 3
	camera.transform.origin = _headbob(t_bob)
	
	var velocity_clamped = clamp(velocity.length(), 0.2, RUNSPEED * 4)
	var target_fov = Base_Fov + Fov_Change * velocity_clamped
	camera.fov = lerp(camera.fov, target_fov, delta * Fov_Change_Speed)

	#print("Old Velocity:",OldVelocity, "|", "Current velocity:", velocity)
	
	if TopVeloctiy < velocity.length():
		TopVeloctiy = velocity.length()
	
	if Zooming:
		get_tree().create_tween().tween_property(camera, "fov", 40, 0.4).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_CUBIC)
	
	print(PissAmount)
	move_and_slide()
func _headbob(time) -> Vector3:
	var Pos = Vector3.ZERO
	Pos.y = sin(time * Bob_Freq) * Bob_Amp
	Pos.x = cos(time * Bob_Freq / 2) * Bob_Amp * 1
	return Pos
	
func _debugresetcamheadrot():
	head.rotation = Vector3.ZERO
	neck.rotation = Vector3.ZERO
	
func _debugrotateadd90degrees():
	neck.rotate_y(deg_to_rad(90))
	
func _CheckForDeath():
	if Health <= 0:
		Dead = true
	else:
		Dead = false
