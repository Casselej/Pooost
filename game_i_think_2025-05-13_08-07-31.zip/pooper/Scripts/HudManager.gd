extends Control

@onready var FpsCounter = $FPSCounter

func _process(delta: float) -> void:
	FpsCounter.text = "FPS: " + str(Engine.get_frames_per_second()) + " Frame time: ~" + str(round(delta * 10000000) / 10000000) + "ms"
